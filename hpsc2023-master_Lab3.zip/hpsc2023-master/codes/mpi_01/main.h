#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstdlib>
#include <sstream>
#include <string>
#include <vector>
#include "math.h"
using std :: string;
using std :: vector;
using std :: stringstream;
using std :: cout;
using std :: endl;


